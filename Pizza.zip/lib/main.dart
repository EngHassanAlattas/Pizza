// ignore_for_file: prefer_const_constructors, duplicate_ignore, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';

void main() {
  // ignore: prefer_const_constructors
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Home(),
  ));
}

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 174, 236, 239),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(60), color: Colors.white),
              height: 240,
              width: 560,
              child: Column(
                children: [
                  Container(
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Image(
                          height: 210,
                          width: 250,
                          image: AssetImage('images/R.jpg')),
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12, right: 6, left: 6),
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(60),
                        color: Colors.white),
                    height: 110,
                    width: 420,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 30),
                      child: Row(
                        children: [
                          Container(
                            margin: EdgeInsets.all(9),
                            child: Image(
                                height: 90,
                                width: 90,
                                image: AssetImage('images/tes.png')),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(2),
                            child: Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 22),
                                  child: Column(
                                    children: [
                                      Text(
                                        'Pizza large meet',
                                        style: TextStyle(fontSize: 25),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(right: 120),
                                        child: Text("Available",
                                            style: TextStyle(fontSize: 15)),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(right: 50),
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            )
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 40),
                                  child: Text(
                                    "\$13",
                                    style: TextStyle(
                                        fontSize: 25,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12, right: 6, left: 6),
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(60),
                        color: Colors.white),
                    height: 110,
                    width: 420,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 30),
                      child: Row(
                        children: [
                          Container(
                            margin: EdgeInsets.all(9),
                            child: Image(
                                height: 90,
                                width: 90,
                                image: AssetImage('images/tes.png')),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(2),
                            child: Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 22),
                                  child: Column(
                                    children: [
                                      Text(
                                        'Pizza large Fish',
                                        style: TextStyle(fontSize: 25),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(right: 120),
                                        child: Text("Available",
                                            style: TextStyle(fontSize: 15)),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(right: 50),
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            )
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 40),
                                  child: Text(
                                    "\$14",
                                    style: TextStyle(
                                        fontSize: 25,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12, right: 6, left: 6),
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(60),
                        color: Colors.white),
                    height: 110,
                    width: 420,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 30),
                      child: Row(
                        children: [
                          Container(
                            margin: EdgeInsets.all(9),
                            child: Image(
                                height: 90,
                                width: 90,
                                image: AssetImage('images/tes.png')),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(2),
                            child: Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 22),
                                  child: Column(
                                    children: [
                                      Text(
                                        'Pizza Medium Fish',
                                        style: TextStyle(fontSize: 22),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(right: 120),
                                        child: Text("Available",
                                            style: TextStyle(fontSize: 15)),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(right: 50),
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            )
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 40),
                                  child: Text(
                                    "\$11",
                                    style: TextStyle(
                                        fontSize: 25,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12, right: 6, left: 6),
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(60),
                        color: Colors.white),
                    height: 110,
                    width: 420,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 30),
                      child: Row(
                        children: [
                          Container(
                            margin: EdgeInsets.all(9),
                            child: Image(
                                height: 90,
                                width: 90,
                                image: AssetImage('images/tes.png')),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(2),
                            child: Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 22),
                                  child: Column(
                                    children: [
                                      Text(
                                        'Pizza large Chicken',
                                        style: TextStyle(fontSize: 20),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(right: 120),
                                        child: Text("Available",
                                            style: TextStyle(fontSize: 15)),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(right: 50),
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.green,
                                            )
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 40),
                                  child: Text(
                                    "\$15",
                                    style: TextStyle(
                                        fontSize: 25,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
